SLSTR PFM Spectral Response README
-----------------------------------

        Tim Nightingale (tim.nightingale@stfc.ac.uk) 07/02/2017



This note accompanies the nine spectral response files:

        SLSTR_PFM_S1_20170207.nc
        SLSTR_PFM_S2_20170207.nc
        SLSTR_PFM_S3_20170207.nc
        SLSTR_PFM_S4_20170207.nc
        SLSTR_PFM_S5_20170207.nc
        SLSTR_PFM_S6_20170207.nc
        SLSTR_PFM_S7_20170207.nc
        SLSTR_PFM_S8_20170207.nc
        SLSTR_PFM_S9_20170207.nc


These files contain the draft measured spectral responses of the nine standard channels S1 - S9 in the focal plane of the SLSTR PFM instrument, to fly on the Sentinel 3B platform. The responses of the fire channels F1 and F2 are identical to the responses of standard channels S7 and S8. The responses are derived from measurements taken during a spectral calibration campaign conducted at the STFC Rutherford Appleton Laboratory (RAL) in February and March 2016 (www.stfc.ac.uk).

The files are encoded in netCDF-4 and follow the Climate and Forecast (CF) metadata convention (cfconventions.org). The basic structures of the files are identical. As an example, the structure of file SLSTR_PFM_S1_20170207 is shown below:

netcdf SLSTR_PFM_S1_20170207 {
dimensions:
	n_data = 4001 ;
variables:
	double wavelength(n_data) ;
		wavelength:long_name = "wavelength" ;
		wavelength:units = "µm" ;
	double response(n_data) ;
		response:long_name = "spectral response" ;
		response:units = "1" ;
		response:coordinates = "wavelength" ;
		response:ancillary_variables = "response_uncertainty_a response_uncertainty_b" ;
		response:_FillValue = -1. ;
		response:scale_factor = 0.14318862917204 ;
		response:add_offset = 0. ;
	double response_relative_variance_a(n_data) ;
		response_relative_variance_a:long_name = "spectral response relative variance (type A)" ;
		response_relative_variance_a:units = "1" ;
		response_relative_variance_a:coordinates = "wavelength" ;
		response_relative_variance_a:_FillValue = -1. ;
	double response_relative_variance_b(n_data) ;
		response_relative_variance_b:long_name = "spectral response relative variance (type B)" ;
		response_relative_variance_b:units = "1" ;
		response_relative_variance_b:coordinates = "wavelength" ;
		response_relative_variance_b:_FillValue = -1. ;
	double response_uncertainty_a(n_data) ;
		response_uncertainty_a:long_name = "spectral response uncertainty (type A)" ;
		response_uncertainty_a:units = "1" ;
		response_uncertainty_a:coordinates = "wavelength" ;
		response_uncertainty_a:_FillValue = -1. ;
		response_uncertainty_a:scale_factor = 0.14318862917204 ;
		response_uncertainty_a:add_offset = 0. ;
	double response_uncertainty_b(n_data) ;
		response_uncertainty_b:long_name = "spectral response uncertainty (type B)" ;
		response_uncertainty_b:units = "1" ;
		response_uncertainty_b:coordinates = "wavelength" ;
		response_uncertainty_b:_FillValue = -1. ;
		response_uncertainty_b:scale_factor = 0.14318862917204 ;
		response_uncertainty_b:add_offset = 0. ;

// global attributes:
		:title = "Resampled Sentinel-3B SLSTR S1 unpolarised FPA response at 87 K" ;
		:created = "2017-02-07T12:16:13Z" ;
		:Conventions = "CF-1.6" ;
		:institution = "STFC Rutherford Appleton Laboratory" ;
		:source = "Bruker IFS 120A spectrometer measurements" ;
		:history = "2017-02-07T12:16:13Z: IDL> fpa_resample" ;
		:comment = "" ;
		:data_sources =
"S3B_0202_04_S1_T087_P999_FTS_sig_20160303T185311Z.bc.nc
    S3B_0201_04_S1_T087_P999_FTS_ref_20160303T184852Zav.0.dat
    S3B_0202_04_S1_T087_P999_FTS_sig_20160303T185311Zav.0.dat
    S3B_0203_02_S1_T087_P999_FTS_ref_20160303T185729Zav.0.dat
    S3B_0700_01_SV_T999_P999_FTS_tta_20160425T093551Z.nc
        S3B_0701_01_SV_T999_P999_FTS_rfa_20160425T093551Zav.0.dat
        S3B_0702_01_SV_T999_P999_FTS_sgb_20160425T101252Zav.0.dat
        S3B_0703_01_SV_T999_P999_FTS_rfb_20160425T110731Zav.0.dat
        S3B_0704_01_SV_T999_P999_FTS_sga_20160425T112936Zav.0.dat
        S3B_0705_01_SV_T999_P999_FTS_sga_20160425T112944Zav.0.dat
        S3B_0706_01_SV_T999_P999_FTS_rfb_20160425T112953Zav.0.dat
        S3B_0707_01_SV_T999_P999_FTS_sgb_20160425T134442Zav.0.dat
        S3B_0708_01_SV_T999_P999_FTS_rfa_20160425T141324Zav.0.dat
    diode_182_20130625.nc\n" ;
}
The file contains a number of global attributes containing basic information about the file, including an indented list “data_sources” tracing the contributing measurement files, and a set of variables describing the spectral response:

1) Variable “wavelength” contains the wavelength axis in units of microns.

2) Variable “response” contains an estimate, in raw measurement units, of the spectral responsivity of the channel to unpolarised light. Multiplication of the raw response values by the scaling factor “response:scale_factor” normalises the response to a peak value of 1.0. The draft calibration report “S3-RP-RAL-SL-102 SLSTR B FPA Spectral Calibration - Draft 0.2.pdf” contains an discussion of the derivation of the spectral responsivities from the direct measurements.

3) Variables “uncertainty_a” and “uncertainty_b” contain estimates, in raw measurement units, of the one-sigma type A and type B uncertainties associated with the measured spectral responsivity. Multiplication of the raw uncertainty values by the scaling factors “uncertainty_a:scale_factor” and “uncertainty_b:scale_factor” normalises them to the uncertainties associated with responses with a peak value of 1.0. Type A uncertainties are derived from the statistics of repeated measurements (e.g. detector noise). Type B uncertainties are those derived by other than statistical methods (e.g. uncertainties in the positions of the measurement baselines). See e.g. physics.nist.gov/cuu/Uncertainty/basic.html. The total estimated measurement uncertainty is the root sum square (RSS) of the two quantities. The draft calibration report contains a discussion of the derivations of the uncertainties.

4) Variables “relative_variance_a” and “relative_variance_b” are derived values: relative_variance_a = (uncertainty_a / response)^2 and relative_variance_b = (uncertainty_b / response)^2.
